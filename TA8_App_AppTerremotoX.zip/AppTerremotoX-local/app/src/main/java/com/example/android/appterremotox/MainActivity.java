package com.example.android.appterremotox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final String LOG_TAG = MainActivity.class.getName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Extrai a lista de terremotos do arquivo JSON que está na classe QueryUtils
        ArrayList<Earthquake> earthquakes = QueryUtils.extractEarthquakes();

        // Encontra o id do layout ListView
        ListView earthquakeListView = (ListView) findViewById(R.id.list);

        // Cria um novo adapter que utiliza a lista de terremotos como entrada
        final EarthquakeAdapter adapter = new EarthquakeAdapter(this, earthquakes);

        earthquakeListView.setAdapter(adapter);
    }
}